let retter; 
async function hentJson ( {
    //hent json
    let jsonData = await fetch("json/menu.json");
    retter = await jsonData.json();
    //console.log (retter);
    //find og filtrer retter efter kategori og dem i nyt array
    
    let foretter = retter.filter(ret => ret.kategori == "foretter");
    let foretter = retter.filter(ret => ret.kategori == "hovedretter");
    let foretter = retter.filter(ret => ret.kategori == "desserter");
    let foretter = retter.filter(ret => ret.kategori == "drikkevarer");
    
    visRetter (foretter);
    
})
    
    function visRetter(retter) {
    let menuTemplate = document.querySelector()
}